package com.deve.assistant

import android.app.Application
import android.content.Context
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Phase { IDLE, STANDBY, LISTENING, THINKING, SPEAKING, RECORDING }

class DeVEViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("deve", Context.MODE_PRIVATE)
    private val executor = ActionExecutor(app)
    private val history = mutableListOf<Pair<String, String>>()

    private val idleCaption = "Touche l'orbe pour parler à DeVE"
    private val standbyCaption = "Dis « DeVE » pour me parler"

    // Détecte « DeVE », « dis Dève », « dev », « dave »… (la reconnaissance vocale écrit ce mot de plusieurs façons)
    private val wakeRegex = Regex("(?i)(?<!\\p{L})(d[eèéê]v[eèéê]?|dav[eé]?|div[eé]?)(?!\\p{L})")

    private var inForeground = true

    var phase by mutableStateOf(Phase.IDLE)
        private set
    var caption by mutableStateOf(idleCaption)
        private set
    var level by mutableFloatStateOf(0f)
        private set
    var handsFree by mutableStateOf(prefs.getBoolean("hands_free", false))
        private set

    var provider by mutableStateOf(
        runCatching { Provider.valueOf(prefs.getString("provider", "GEMINI") ?: "GEMINI") }
            .getOrDefault(Provider.GEMINI)
    )
        private set
    var claudeKey by mutableStateOf(
        prefs.getString("key_claude", null) ?: prefs.getString("api_key", "") ?: ""
    )
        private set
    var geminiKey by mutableStateOf(prefs.getString("key_gemini", "") ?: "")
        private set
    var geminiModel by mutableStateOf(
        prefs.getString("gemini_model", AiClient.DEFAULT_GEMINI_MODEL) ?: AiClient.DEFAULT_GEMINI_MODEL
    )
        private set

    val apiKey: String
        get() = if (provider == Provider.CLAUDE) claudeKey else geminiKey

    private val voice = VoiceEngine(
        app,
        onRms = { level = it },
        onResult = { onHeard(it) },
        onError = { onVoiceError(it) }
    )

    // ---------- Réglages ----------

    fun saveSettings(p: Provider, claude: String, gemini: String, model: String) {
        provider = p
        claudeKey = claude.trim()
        geminiKey = gemini.trim()
        geminiModel = model.trim().ifBlank { AiClient.DEFAULT_GEMINI_MODEL }
        prefs.edit()
            .putString("provider", p.name)
            .putString("key_claude", claudeKey)
            .putString("key_gemini", geminiKey)
            .putString("gemini_model", geminiModel)
            .apply()
        if (phase == Phase.IDLE) {
            caption = idleCaption
            if (handsFree) scheduleStandby(200)
        }
    }

    // ---------- Mains libres ----------

    fun setHandsFree(on: Boolean) {
        handsFree = on
        prefs.edit().putBoolean("hands_free", on).apply()
        if (on) {
            if (apiKey.isBlank()) {
                caption = "Ajoute une clé API dans Réglages."
                return
            }
            if (phase == Phase.IDLE) startStandby()
        } else if (phase == Phase.STANDBY) {
            voice.cancelListening()
            level = 0f
            phase = Phase.IDLE
            caption = idleCaption
        }
    }

    fun onForeground() {
        inForeground = true
        if (handsFree && phase == Phase.IDLE) scheduleStandby(300)
    }

    fun onBackground() {
        inForeground = false
        if (phase == Phase.STANDBY || phase == Phase.LISTENING) {
            voice.cancelListening()
            level = 0f
            phase = Phase.IDLE
            caption = idleCaption
        }
    }

    private fun startStandby() {
        if (!handsFree || apiKey.isBlank() || !inForeground) return
        phase = Phase.STANDBY
        caption = standbyCaption
        voice.startListening()
    }

    private fun scheduleStandby(delayMs: Long) {
        viewModelScope.launch {
            delay(delayMs)
            if (handsFree && inForeground && (phase == Phase.STANDBY || phase == Phase.IDLE)) startStandby()
        }
    }

    private fun afterReply() {
        phase = Phase.IDLE
        caption = idleCaption
        if (handsFree) scheduleStandby(300)
    }

    // ---------- Interaction ----------

    fun onOrbTap() {
        when (phase) {
            Phase.IDLE, Phase.STANDBY -> startListening()
            Phase.LISTENING -> voice.stopListening()
            Phase.SPEAKING -> {
                voice.stopSpeaking()
                afterReply()
            }
            Phase.RECORDING -> stopRecording()
            Phase.THINKING -> Unit
        }
    }

    private fun startListening() {
        if (apiKey.isBlank()) {
            phase = Phase.IDLE
            caption = "Ajoute une clé API dans Réglages."
            return
        }
        phase = Phase.LISTENING
        caption = "Je t'écoute…"
        voice.startListening()
    }

    private fun onHeard(text: String) {
        level = 0f
        if (phase == Phase.STANDBY) {
            val match = wakeRegex.find(text)
            if (match == null) {
                scheduleStandby(250) // ce n'était pas pour DeVE : on continue d'écouter
                return
            }
            val command = text.substring(match.range.last + 1)
                .trim().trimStart(',', '.', '!', '?', ' ').trim()
            if (command.isBlank()) askForCommand() else process(command)
        } else {
            process(text)
        }
    }

    private fun askForCommand() {
        phase = Phase.SPEAKING
        caption = "Oui ?"
        voice.speak("Oui ?") {
            phase = Phase.LISTENING
            caption = "Je t'écoute…"
            voice.startListening()
        }
    }

    private fun process(text: String) {
        caption = "« $text »"
        phase = Phase.THINKING
        viewModelScope.launch {
            try {
                val reply = AiClient.ask(provider, apiKey, geminiModel, history.toList(), text)
                history += "user" to text
                history += "assistant" to reply.raw

                if (reply.action.type == "record_start") {
                    // On parle d'abord, puis on lance l'enregistrement (pour ne pas enregistrer la voix de DeVE).
                    phase = Phase.SPEAKING
                    caption = reply.speech
                    voice.speak(reply.speech) {
                        val r = executor.execute(reply.action)
                        if (r.error != null) {
                            caption = r.error
                            phase = Phase.IDLE
                            if (handsFree) scheduleStandby(2500)
                        } else {
                            phase = Phase.RECORDING
                            caption = "Enregistrement en cours…\nTouche l'orbe pour arrêter"
                        }
                    }
                } else {
                    val r = executor.execute(reply.action)
                    val say = r.error ?: r.info ?: reply.speech
                    phase = Phase.SPEAKING
                    caption = say
                    voice.speak(say) { afterReply() }
                }
            } catch (e: Exception) {
                phase = Phase.IDLE
                val m = e.message ?: ""
                caption = when {
                    m.contains("401") || m.contains("403") || m.contains("API 400") ->
                        "Clé API refusée. Vérifie-la dans Réglages."
                    m.contains("429") -> "Trop de demandes d'un coup. Patiente un instant puis réessaie."
                    m.contains("404") -> "Modèle introuvable. Change le modèle dans Réglages."
                    else -> "Impossible de joindre l'IA. Vérifie ta connexion."
                }
                if (handsFree) scheduleStandby(3000)
            }
        }
    }

    private fun stopRecording() {
        val r = executor.execute(DeVEAction("record_stop"))
        caption = r.error ?: r.info ?: "Enregistrement terminé."
        phase = Phase.SPEAKING
        voice.speak("Enregistrement terminé.") { afterReply() }
    }

    private fun onVoiceError(code: Int) {
        level = 0f
        when (code) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                phase = Phase.IDLE
                caption = "Autorise le micro pour DeVE."
            }
            -1 -> {
                phase = Phase.IDLE
                caption = "La reconnaissance vocale n'est pas disponible sur ce téléphone."
            }
            else -> {
                if (handsFree && inForeground && apiKey.isNotBlank()) {
                    // Silence, bruit, erreur passagère : on reste à l'écoute.
                    phase = Phase.STANDBY
                    caption = standbyCaption
                    val wait = when (code) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 200L
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1000L
                        else -> 1500L
                    }
                    scheduleStandby(wait)
                } else {
                    phase = Phase.IDLE
                    caption = when (code) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "Je n'ai rien entendu. Touche l'orbe pour réessayer."
                        else -> "Erreur vocale ($code). Réessaie."
                    }
                }
            }
        }
    }

    override fun onCleared() {
        voice.destroy()
        executor.release()
    }
}
