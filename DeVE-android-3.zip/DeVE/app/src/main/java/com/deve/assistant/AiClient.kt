package com.deve.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

enum class Provider { CLAUDE, GEMINI }

data class DeVEReply(val raw: String, val speech: String, val action: DeVEAction)

object AiClient {

    const val DEFAULT_GEMINI_MODEL = "gemini-2.5-flash-lite"
    private const val CLAUDE_MODEL = "claude-sonnet-5-5"

    private val SYSTEM = """
Tu es DeVE, un assistant vocal sur le téléphone Android de l'utilisateur.
Tu parles français, de façon brève et chaleureuse : une phrase courte, car elle est dite à voix haute (pas de markdown, pas d'emoji).
Tu réponds TOUJOURS et UNIQUEMENT avec un objet JSON, sans aucun texte autour :
{"speech":"ce que tu dis à voix haute","action":{"type":"...","target":"..."}}
Types d'action possibles :
- none : simple conversation ou question
- call : appeler quelqu'un (target = nom du contact ou numéro)
- launch_app : ouvrir une application (target = nom de l'application)
- close_app : quitter l'application en cours et revenir à l'accueil
- record_start : démarrer un enregistrement audio
- record_stop : arrêter l'enregistrement
N'invente jamais de numéro de téléphone. Si la demande est ambiguë, pose une question courte avec l'action none.
""".trimIndent()

    suspend fun ask(
        provider: Provider,
        apiKey: String,
        geminiModel: String,
        history: List<Pair<String, String>>,
        userText: String
    ): DeVEReply = withContext(Dispatchers.IO) {
        val h = history.takeLast(10)
        val raw = when (provider) {
            Provider.CLAUDE -> callClaude(apiKey, h, userText)
            Provider.GEMINI -> callGemini(apiKey, geminiModel, h, userText)
        }
        parse(raw)
    }

    private fun callClaude(key: String, history: List<Pair<String, String>>, userText: String): String {
        val msgs = JSONArray()
        history.forEach { (role, content) ->
            msgs.put(JSONObject().put("role", role).put("content", content))
        }
        msgs.put(JSONObject().put("role", "user").put("content", userText))
        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put("messages", msgs)
        val text = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body
        )
        return JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun callGemini(
        key: String, model: String, history: List<Pair<String, String>>, userText: String
    ): String {
        fun turn(role: String, text: String) = JSONObject()
            .put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text)))

        val contents = JSONArray()
        history.forEach { (role, content) ->
            contents.put(turn(if (role == "assistant") "model" else "user", content))
        }
        contents.put(turn("user", userText))

        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM)))
            )
            .put("contents", contents)
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("maxOutputTokens", 400)
            )
        val text = post(
            "https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent",
            mapOf("x-goog-api-key" to key),
            body
        )
        return JSONObject(text)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
            ?.optString("text")
            ?.takeIf { it.isNotBlank() }
            ?: throw IOException("Réponse vide")
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IOException("API $code")
        return text
    }

    private fun parse(raw: String): DeVEReply {
        return try {
            val json = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
            val act = json.optJSONObject("action")
            DeVEReply(
                raw = raw,
                speech = json.optString("speech", ""),
                action = DeVEAction(
                    type = act?.optString("type", "none") ?: "none",
                    target = act?.optString("target", "") ?: ""
                )
            )
        } catch (e: Exception) {
            DeVEReply(raw, raw.take(200), DeVEAction("none"))
        }
    }
}
