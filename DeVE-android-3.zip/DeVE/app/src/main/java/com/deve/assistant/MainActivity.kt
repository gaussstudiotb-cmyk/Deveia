package com.deve.assistant

import android.Manifest
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    private val vm: DeVEViewModel by viewModels()

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissions.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            )
        )
        setContent { DeVEScreen(vm) }
    }

    override fun onStart() {
        super.onStart()
        vm.onForeground()
    }

    override fun onStop() {
        vm.onBackground()
        super.onStop()
    }
}

@Composable
fun DeVEScreen(vm: DeVEViewModel) {
    var showKey by remember { mutableStateOf(vm.apiKey.isBlank()) }
    val activity = LocalContext.current as ComponentActivity
    LaunchedEffect(vm.handsFree) {
        if (vm.handsFree) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF080210), Color(0xFF1B0730), Color(0xFF2A0A3A))
                )
            )
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "DeVE", color = Color.White, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 3.sp
            )
            TextButton(onClick = { showKey = true }) {
                Text("Réglages", color = DeVEPink)
            }
        }

        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Orb(
                phase = vm.phase,
                level = vm.level,
                modifier = Modifier
                    .size(300.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { vm.onOrbTap() }
            )
            Spacer(Modifier.height(24.dp))
            Text(
                vm.caption,
                color = Color(0xFFE9D5F5),
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 32.dp)
            )
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = { vm.setHandsFree(!vm.handsFree) }) {
                Text(
                    if (vm.handsFree) "Mains libres : activé" else "Mains libres : désactivé",
                    color = if (vm.handsFree) DeVEPink else Color(0xFF8E7AA3),
                    fontWeight = if (vm.handsFree) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }

    if (showKey) SettingsDialog(
        vm = vm,
        canDismiss = vm.apiKey.isNotBlank(),
        onDismiss = { showKey = false },
        onSave = { p, c, g, m -> vm.saveSettings(p, c, g, m); showKey = false }
    )
}

@Composable
private fun SettingsDialog(
    vm: DeVEViewModel,
    canDismiss: Boolean,
    onDismiss: () -> Unit,
    onSave: (Provider, String, String, String) -> Unit
) {
    var provider by remember { mutableStateOf(vm.provider) }
    var claudeKey by remember { mutableStateOf(vm.claudeKey) }
    var geminiKey by remember { mutableStateOf(vm.geminiKey) }
    var model by remember { mutableStateOf(vm.geminiModel) }
    val current = if (provider == Provider.CLAUDE) claudeKey else geminiKey

    AlertDialog(
        onDismissRequest = { if (canDismiss) onDismiss() },
        containerColor = Color(0xFF1B0730),
        title = { Text("Réglages", color = Color.White) },
        text = {
            Column {
                Row {
                    TextButton(onClick = { provider = Provider.GEMINI }) {
                        Text(
                            "Gemini (gratuit)",
                            color = if (provider == Provider.GEMINI) DeVEPink else Color(0xFF8E7AA3),
                            fontWeight = if (provider == Provider.GEMINI) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                    TextButton(onClick = { provider = Provider.CLAUDE }) {
                        Text(
                            "Claude",
                            color = if (provider == Provider.CLAUDE) DeVEPink else Color(0xFF8E7AA3),
                            fontWeight = if (provider == Provider.CLAUDE) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
                Text(
                    if (provider == Provider.GEMINI)
                        "Clé gratuite sur aistudio.google.com/apikey. Elle reste sur ce téléphone."
                    else
                        "Clé sur console.anthropic.com (payant). Elle reste sur ce téléphone.",
                    color = Color(0xFFD9C2EE), fontSize = 14.sp
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = current,
                    onValueChange = {
                        if (provider == Provider.CLAUDE) claudeKey = it else geminiKey = it
                    },
                    label = { Text("Clé API") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                if (provider == Provider.GEMINI) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Modèle Gemini") },
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(provider, claudeKey, geminiKey, model) },
                enabled = current.isNotBlank()
            ) {
                Text("Enregistrer", color = DeVEPink)
            }
        }
    )
}
