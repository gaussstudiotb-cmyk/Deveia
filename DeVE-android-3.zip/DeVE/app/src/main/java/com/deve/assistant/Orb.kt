package com.deve.assistant

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

val DeVEViolet = Color(0xFF6A1FB8)
val DeVEDeepViolet = Color(0xFF1E0838)
val DeVEPink = Color(0xFFE0307A)
val DeVEDarkPink = Color(0xFF9C1B5E)

@Composable
fun Orb(phase: Phase, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(16000, easing = LinearEasing)),
        label = "spin"
    )
    val pulse by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val lvl by animateFloatAsState(level, tween(90), label = "lvl")

    val energy = when (phase) {
        Phase.IDLE -> 0.10f + 0.08f * pulse
        Phase.STANDBY -> 0.14f + 0.10f * pulse
        Phase.LISTENING -> 0.25f + lvl * 0.75f
        Phase.THINKING -> 0.55f + 0.25f * pulse
        Phase.SPEAKING -> 0.45f + 0.35f * pulse
        Phase.RECORDING -> 0.30f + 0.20f * pulse
    }

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f * 0.6f * (1f + 0.1f * energy)

        // Halo
        drawCircle(
            brush = Brush.radialGradient(
                listOf(
                    DeVEPink.copy(alpha = 0.25f + 0.3f * energy),
                    DeVEViolet.copy(alpha = 0.12f),
                    Color.Transparent
                ),
                center = c, radius = r * 1.7f
            ),
            radius = r * 1.7f, center = c
        )

        val clip = Path().apply { addOval(Rect(c, r)) }
        clipPath(clip) {
            // Fond de l'orbe
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF2B0B4D), Color(0xFF0E0319)),
                    center = c, radius = r
                ),
                radius = r, center = c
            )
            // Nappes de couleur mouvantes
            val cols = listOf(DeVEPink, DeVEViolet, DeVEDarkPink)
            for (i in 0..2) {
                val deg = spin * (if (i % 2 == 0) 1f else -1f) * (i + 1) + i * 120f
                val a = Math.toRadians(deg.toDouble())
                val d = r * (0.18f + 0.32f * energy)
                val o = Offset(c.x + cos(a).toFloat() * d, c.y + sin(a).toFloat() * d)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(cols[i].copy(alpha = 0.85f), Color.Transparent),
                        center = o, radius = r * 0.95f
                    ),
                    radius = r * 0.95f, center = o, blendMode = BlendMode.Plus
                )
            }
            // Reflet
            val hl = Offset(c.x - r * 0.35f, c.y - r * 0.45f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                    center = hl, radius = r * 0.6f
                ),
                radius = r * 0.6f, center = hl
            )
        }

        // Anneau lumineux
        drawCircle(
            brush = Brush.sweepGradient(
                listOf(DeVEPink, DeVEViolet, DeVEDarkPink, DeVEPink), center = c
            ),
            radius = r, center = c, alpha = 0.9f, style = Stroke(3.dp.toPx())
        )
    }
}
