package com.deve.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Sert uniquement à effectuer l'action globale « Accueil » pour quitter une appli. */
class DeVEAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: DeVEAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
