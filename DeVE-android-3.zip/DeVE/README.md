# DeVE — assistant vocal Android

IA au choix : Gemini (clé gratuite sur aistudio.google.com/apikey) ou Claude (console.anthropic.com).
Réglages dans l'appli pour choisir et coller la clé.

Mains libres : touche « Mains libres » ; dis ensuite « DeVE, appelle Maman » (ou « DeVE » seul, puis ta demande).
Fonctionne appli ouverte et écran allumé.

Compilation sans ordinateur : voir build.yml (GitHub Actions).
